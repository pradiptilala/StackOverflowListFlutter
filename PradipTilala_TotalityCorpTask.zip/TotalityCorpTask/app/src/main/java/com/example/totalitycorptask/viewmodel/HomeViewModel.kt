package com.example.totalitycorptask.viewmodel

import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {
    var imageUrl: String = ""
}